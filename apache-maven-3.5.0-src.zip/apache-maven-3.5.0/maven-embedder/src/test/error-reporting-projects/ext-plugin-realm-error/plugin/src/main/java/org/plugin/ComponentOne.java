package org.plugin;

public class ComponentOne
{

    private ComponentTwo two;

}
